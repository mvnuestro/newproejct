import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import {LoginPage} from '../pages/auth/login/login';
import {ProfilePage} from '../pages/auth/profile/profile';
import {SignupBasicPage} from '../pages/auth/sign-up-basic/sign-up-basic';
import {SignupTimingsPage} from '../pages/auth/sign-up-timings/sign-up-timings';
import {HireAgentPage } from '../pages/hire-agent/hire-agent';
import {SignupPaymentPage} from '../pages/auth/sign-up-payment/sign-up-payment';
import { AllActiveReservationsPage } from '../pages/all-active-reservations/all-active-reservations';
import { PastReservationsPage } from '../pages/past-reservations/past-reservations';

import { UserService } from '../providers/user-service';
import { UtilityService } from '../providers/utility-service';
import { PaymentService } from '../providers/payment-service';
import { HttpService } from '../providers/http-service';
import { RestaurantService, ReservationService } from '../providers/restaurant-service';

import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { AngularFireModule } from 'angularfire2' ;
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { IonicStorageModule } from '@ionic/storage';
import { Stripe } from '@ionic-native/stripe';

var firebaseConfig = {
  apiKey: "AIzaSyDvsJ-LRFtL8RLQPtEN9sWvia2kx3uhSIU",
  authDomain: "kweeber-9575e.firebaseapp.com",
  databaseURL: "https://kweeber-9575e.firebaseio.com",
  projectId: "kweeber-9575e",
  storageBucket: "",
  messagingSenderId: "993450317354"
};

@NgModule({
  declarations: [
    MyApp,
    TabsPage,
    LoginPage,
    ProfilePage,
    HireAgentPage,
    AllActiveReservationsPage,
    PastReservationsPage,
    SignupBasicPage,
    SignupTimingsPage,
    SignupPaymentPage
  ],
  imports: [
    BrowserModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    HttpClientModule,
    HttpModule,
    IonicStorageModule.forRoot(),
    IonicModule.forRoot(MyApp,{
      backButtonText: ''
      // iconMode: 'ios',
      // modalEnter: 'modal-slide-in',
      // modalLeave: 'modal-slide-out',
      // tabsPlacement: 'bottom',
      // pageTransition: 'ios-transition'
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TabsPage,
    LoginPage,
    ProfilePage,
    AllActiveReservationsPage,
    PastReservationsPage,
    SignupBasicPage,
    SignupTimingsPage,
    SignupPaymentPage,
    HireAgentPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    UserService,
    RestaurantService,
    ReservationService,
    PaymentService,
    HttpService,
    UtilityService,
    Stripe,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
