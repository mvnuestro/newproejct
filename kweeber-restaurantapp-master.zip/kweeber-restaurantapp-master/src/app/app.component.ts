import { ProfilePage } from './../pages/auth/profile/profile';
import { SignupTimingsPage } from './../pages/auth/sign-up-timings/sign-up-timings';
import { HireAgentPage } from './../pages/hire-agent/hire-agent';
import { TabsPage } from './../pages/tabs/tabs';
import { AllActiveReservationsPage } from './../pages/all-active-reservations/all-active-reservations';
import { Component,ViewChild } from '@angular/core';
import { Platform, AlertController, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AngularFireAuth } from 'angularfire2/auth';
import { UserService } from '../providers/user-service';
import { SignupPaymentPage } from '../pages/auth/sign-up-payment/sign-up-payment'
import { LoginPage } from '../pages/auth/login/login';
import { MenuController } from 'ionic-angular';
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
  rootPage:any = LoginPage;
  // rootPage:any = SignupTimingsPage
  // rootPage:any = TabsPage;

  constructor(platform: Platform, 
    statusBar: StatusBar, 
    public alertCtrl: AlertController,
    private afAuth: AngularFireAuth,
    public user: UserService,
    public menuCtrl: MenuController,
    splashScreen: SplashScreen) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }
  showLogout() {
    // console.log
    let alert = this.alertCtrl.create({
      title: 'Confirm Log Out',
      message: 'Are you sure you want to log out?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            this.menuCtrl.close();
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
          console.log('Logged out');
          // this.navCtrl.setRoot(LoginPage) ;
          this.user.clear();
          this.afAuth
          .auth.signOut()
          .then (value => {
            console.log('Logout Successfull');
            this.menuCtrl.close();
            this.navCtrl.setRoot(LoginPage) ;
          })
          .catch(err => {
        
            console.log('logout error:',err.message);
          });

        }
        }
      ]
    });
    
    alert.present();
  
  }

  goToProfilePage() {
    this.navCtrl.push(ProfilePage);
    this.menuCtrl.close();
  }
  
  goToHireAgentPage() {
    this.navCtrl.push(HireAgentPage);
    this.menuCtrl.close();
  }

  goToSignupTimingsPage () {
    this.navCtrl.push(SignupTimingsPage, {
      'accountMode': 'update'
    });
    this.menuCtrl.close();
  }
  
  goToBankPage() {
    this.navCtrl.push(SignupPaymentPage, {
      'bankMode': 'display'
    });
    this.menuCtrl.close();
  }

}
