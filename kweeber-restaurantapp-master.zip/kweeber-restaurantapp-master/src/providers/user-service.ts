import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
    uid: string;
    paymentacct: string;
    name: string;
    owner: string; 
    address: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    email: string;
    password: string;
    banksetup: string;
    rate: string;
    profile: string;
    timings: any;
    agenttype: string;

  constructor() {
      
  }

  clear(){
    this.uid = '';
    this.paymentacct = '';
    this.name = '';
    this.owner = '';
    this.address = '';
    this.city = '';
    this.state = '';
    this.zip = '';
    this.phone = '';
    this.email = '';
    this.password = '';
    this.banksetup = '';
    this.rate = '';
    this.profile = '';
  }
}