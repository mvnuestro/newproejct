// import { UtilityService } from './utility-service';
import { Injectable } from '@angular/core';
import { Stripe } from '@ionic-native/stripe';
import { HttpService } from './http-service'
import {  LoadingController } from 'ionic-angular';

@Injectable()
export class PaymentService {
  stripeApiKey = 'pk_test_tHTnjaptLKJIUvx8Gt0S1nGh';  // test API
  accountUrl = 'https://api.stripe.com/v1/accounts';
  loaderIsPresent = false;

  constructor ( public stripe: Stripe,
                private httpService: HttpService,
                // private utilityService: UtilityService,
                private loadingCtrl: LoadingController) {

    this.stripe.setPublishableKey(this.stripeApiKey);

  }

  // Get Bank details of Agent account
  getBankInfo(stripeAcct) {
    return new Promise ((resolve,reject) => {
      let url = this.accountUrl + '/' + stripeAcct;
      // console.log("Agent Stripe API URL ->", url);
      let loading = this.loadingCtrl.create({
        content: 'Retrieving Bank Information...'
      });

      loading.present().then((result) => {
        this.loaderIsPresent = true;
      });
    
      // Retrieve Stripe Account for Agent
      this.httpService.post_new(url,'')
      .then((result: any) => {
        // console.log("Agent Stripe Account -->", JSON.stringify(result));
        loading.dismiss().then(() => {
          this.loaderIsPresent = false;
        });
        resolve(result);
      }, (error) => {
        loading.dismiss().then(() => {
          this.loaderIsPresent = false;
        });
        // this.utilityService.showErrorAlert();
        let err = 'New Agent Stripe Account Error - ' + error;
        reject(err);
      });
    });
  }

  // Main method to create Stripe account for Agent
  createAccount(dataStr, accountParams) {
    return new Promise((resolve, reject) => {
      console.log("inside payment service - create account")
      let loading = this.loadingCtrl.create({
        content: 'Please wait...'
      });

      loading.present().then((result) => {
        this.loaderIsPresent = true;
      });
    
      // Create an Stripe Account for Agent
      this.httpService.post_new(this.accountUrl, dataStr)
      .then((result: any) => {
        // console.log("result -->", JSON.stringify(result));

        // Create a Bank Account for Agent
        this.stripe.createBankAccountToken(accountParams)
          .then((bankAccount: any) => {
            // console.log("bankAccount -->", JSON.stringify(bankAccount));
            if (bankAccount.id) {

              // Link Bank Account to Agent Stripe account
              let url = 'https://api.stripe.com/v1/accounts/' + result.id + '/external_accounts';
              var dataStr = 'external_account=' + bankAccount.id;
              this.httpService.post_new(url, dataStr)
                .then((res: any) => {
                  loading.dismiss();
                  resolve(res.account);
                }, (error) => {
                  loading.dismiss().then(() => {
                    this.loaderIsPresent = false;
                  });
                  let err = 'Bank Account Linking Error - ' + error;
                  reject(err);
                });
            }
          }, (error: any) => {
            loading.dismiss().then(() => {
              this.loaderIsPresent = false;
            });
            // this.utilityService.showErrorAlert('Create Account',error)
            let err = 'New Bank Account Error - ' + error;
            reject(err);
          })
      }, (error) => {
        loading.dismiss().then(() => {
          this.loaderIsPresent = false;
        });
        // this.utilityService.showErrorAlert();
        let err = 'New Agent Stripe Account Error - ' + error;
        reject(err);
      });
    })
  }

}