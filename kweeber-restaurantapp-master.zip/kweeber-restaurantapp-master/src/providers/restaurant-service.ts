
import { Injectable } from '@angular/core';
// import { Subscription } from "rxjs/Subscription";
// import {AngularFireDatabase } from 'angularfire2/database';
// import { UserService } from '../providers/user-service';
// import * as moment from 'moment';

@Injectable()
export class RestaurantService {
    id: string;
    name: string;
    owner: string; 
    phone: string;
    timeslots: [{
        time: string,
        slots: string
    }]

  constructor() {   
  }
}

export class ReservationService {
    pastReservations = [];
    activeReservations = [];
    id: string;
    fname: string;
    lname: string;
    phone: string;
    email: string;
    persons: string;
    date: string;
    timeslot: string;
    // reservationListRef$: Subscription = new Subscription();

    constructor(  
        //   public afDB: AngularFireDatabase,
        //   public user: UserService
    ) {
        
    }

    // subReservations() {
    //     // var afDB: AngularFireDatabase = new AngularFireDatabase();
    //     this.activeReservations = [];
    //     this.pastReservations = [];
    //     let tDate = String(moment(new Date()).format('YYYY-MM-DD'));
         
    //     console.log("today's date - ", tDate)
    //      this.reservationListRef$ = this.afDB.list('/Reservations', ref => ref.orderByChild('restaurantid').equalTo(this.user.uid)).valueChanges().subscribe (afReservationList =>  {
    //       console.log("inside reservation sub service");
    //       afReservationList.forEach(afReservation => {
    //         //   if (afReservation.date >= tDate ) {
    //             this.activeReservations.push(afReservation);
    //         //   } else {
    //         //     this.pastReservations.push(afReservation);
    //         //   }
    //       });
    
    //     //   this.activeReservations.sort( function(a,b) {
    //     //     if ( a.date < b.date ){
    //     //       return -1;
    //     //     } else if( a.date > b.date ){
    //     //         return 1;
    //     //     } else{
    //     //       return 0;	
    //     //     }
    //     //   });
    
    //     //   this.pastReservations.sort( function(a,b) {
    //     //     if ( a.date < b.date ){
    //     //       return -1;
    //     //     } else if( a.date > b.date ){
    //     //         return 1;
    //     //     } else{
    //     //       return 0;	
    //     //     }
    //     //   });
    
    //     //   this.reservation.pastReservations = this.pastReservations;
    
    //       console.log("ACTIVE ->", JSON.stringify(this.activeReservations));
    //     //   console.log("PAST ->", JSON.stringify(this.pastReservations));
    //     });
    // }

    // unsubReservations() {
    //     // this.reservationListRef$.unsubscribe();
    // }
  }

export class RestaurantTableService {
    id: string;
    date: string;
    availableTimeslots: [{
        time: string,
        slots: string
    }]
  constructor() {
      
  }

}


