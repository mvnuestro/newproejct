import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import {AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { UserService } from '../../providers/user-service'
import * as firebase from 'firebase';
import { Subscription } from "rxjs/Subscription";

/**
 * Generated class for the HireAgentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-hire-agent',
  templateUrl: 'hire-agent.html',
})
export class HireAgentPage {
  selectAgentType: boolean;
  agentType: string;
  freelancers = [];
  // freelancerListRef$: Observable <any> ;
  freelancerListRef$: Subscription = new Subscription() ;
  

  constructor(public navCtrl: NavController, 
    private afDB: AngularFireDatabase,
    private alertCtrl: AlertController,
    public user: UserService,
    public navParams: NavParams) {

      if (user.agenttype == '' || user.agenttype == null) {
        this.agentType = 'kbot';
      } else {
        this.agentType = user.agenttype;
      }
      console.log("agentType -", this.agentType);
  }

  ionViewWillEnter(){
    this.selectAgentType = true;

    // Get a list of Freelancers
    this.freelancers = [];
    this.freelancerListRef$ = this.afDB.list('/Agents', ref => ref.orderByChild('available').equalTo('yes')).valueChanges().subscribe (

    // this.freelancerListRef$.subscribe( 
      affreelancerList =>  {
      console.log("inside freelancer");
      affreelancerList.forEach(affreelancer => {
        this.freelancers.push(affreelancer);
      });

      this.freelancers.sort( function(a,b) {
        if ( a.rate < b.rate ){
          return -1;
        } else if( a.rate > b.rate ){
            return 1;
        } else{
          return 0;	
        }
      })

      console.log("FREELANCERS ->", JSON.stringify(this.freelancers));
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad HireAgentPage');
  }

  ionViewWillUnload() {
    console.log("Unsubscribing freelancerList");
    this.freelancerListRef$.unsubscribe();
  }

  showAgents() {
    this.selectAgentType = false;
    console.log(this.agentType);

    if (this.agentType != 'freelancer') {
      // Save AgentType in the profile
      firebase.database().ref().child('Restaurants').child(this.user.uid).update({
        agenttype: this.agentType,
        freelancerid: ' '
      }).then((success)=> {
        console.log("Saved Agent Type");
      }).catch ((error) => {
        alert ("Error Storing AgentType")
      })

      // this.freelancerListRef$.unsubscribe();
      this.navCtrl.pop();
    }
  }

  save(uid, fname, lname) {
    console.log("Freelancer id - ", uid);
    let alert = this.alertCtrl.create({
      title: 'Confirm Hire',
      message: 'Would you like to hire ' + fname + ' ' + lname + '?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            // Save Freelancer Id in Restaurant
            firebase.database().ref().child('Restaurants').child(this.user.uid).update({
              agenttype: this.agentType,
              freelancerid: uid
            }).then((success)=> {
              console.log("Saved Agent Type");
            }).catch ((error) => {
              console.log ("Error Storing AgentType")
            })

            // Save Restaurant ID in Agent profile
            firebase.database().ref().child('Agents').child(uid).child('restaurants').child(this.user.uid).update({
              restaurantid: this.user.uid,
              name: this.user.name   // restaurant name
            }).then((success)=> {
              console.log("Saved Agent Type");
            }).catch ((error) => {
              console.log ("Error Storing AgentType")
            }) 

            this.navCtrl.pop();
          }
        }
      ]
    });
    
    alert.present();
  }

}
