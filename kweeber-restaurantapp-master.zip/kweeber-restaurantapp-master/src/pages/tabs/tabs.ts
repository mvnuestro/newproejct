import { Component } from '@angular/core';

import { AllActiveReservationsPage } from '../all-active-reservations/all-active-reservations';
import { PastReservationsPage } from '../past-reservations/past-reservations';
// import { settingsPage } from '../past-reservations/settings';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = AllActiveReservationsPage;
  tab2Root = PastReservationsPage;


  constructor() {

  }
}
