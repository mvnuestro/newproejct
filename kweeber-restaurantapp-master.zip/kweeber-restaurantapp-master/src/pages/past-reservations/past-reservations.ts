import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { RestaurantService, ReservationService } from '../../providers/restaurant-service';

/**
 * Generated class for the PastReservationsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-past-reservations',
  templateUrl: 'past-reservations.html',
})
export class PastReservationsPage {
  pastReservations = [];

  constructor(public navCtrl: NavController, 
    public reservation: ReservationService,
    public navParams: NavParams) {
      
  }

  ionViewWillEnter(){
    console.log("Inside Past Reservations");
    console.log(this.reservation.pastReservations);
    this.pastReservations = this.reservation.pastReservations;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PastReservationsPage');
  }

}
