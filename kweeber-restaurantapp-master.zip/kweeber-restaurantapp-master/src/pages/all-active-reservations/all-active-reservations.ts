import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
// import { ReservationDetailPage } from '../reservation-detail/reservation-detail';
// import { AllActiveReservationsPage } from '../all-active-reservations/all-active-reservations';
import { RestaurantService, ReservationService } from '../../providers/restaurant-service';
import {AngularFireDatabase } from 'angularfire2/database';

// import { Observable } from 'rxjs/Observable';
// import * as firebase from 'firebase';
import { UserService } from '../../providers/user-service';
import * as moment from 'moment';
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: 'page-all-active-reservations',
  templateUrl: 'all-active-reservations.html'
})
export class AllActiveReservationsPage {
  restaurants = [];
  activeReservations = [];
  pastReservations = [];
  reservationListRef$: Subscription = new Subscription();

  constructor(public navCtrl: NavController,
              public reservation: ReservationService,
              public restaurant: RestaurantService,
              private afDB: AngularFireDatabase,
              public user: UserService) {
      console.log("========>>>>> IN RESERVATION <<<<<<<========== ")
  }

  ionViewWillEnter(){
    this.activeReservations = [];
    this.pastReservations = [];
    let tDate = String(moment(new Date()).format('YYYY-MM-DD'));
    console.log("today's date - ", tDate)
    // const reservationListRef$: Observable <any> = this.afDB.list('/Reservations').valueChanges();
    // var reservationListRef$: Observable <any>  = this.afDB.list('/Reservations', ref => ref.orderByChild('restaurantid').equalTo(this.user.uid)).valueChanges();
    this.reservationListRef$ = this.afDB.list('/Reservations', ref => ref.orderByChild('restaurantid').equalTo(this.user.uid)).valueChanges().subscribe (afReservationList =>  {
      console.log("inside reservation");
      let reservations: any = [];
      afReservationList.forEach(afReservation => {
        reservations.push(afReservation);
      });

      reservations.forEach(reservation => {
        if (reservation.date >= tDate ) {
          this.activeReservations.push(reservation);
        } else {
          this.pastReservations.push(reservation);
        }
      });

      this.activeReservations.sort( function(a,b) {
        if ( a.date < b.date ){
          return -1;
        } else if( a.date > b.date ){
            return 1;
        } else{
          return 0;	
        }
      })

      this.pastReservations.sort( function(a,b) {
        if ( a.date < b.date ){
          return -1;
        } else if( a.date > b.date ){
            return 1;
        } else{
          return 0;	
        }
      })

      this.reservation.pastReservations = this.pastReservations;

      // console.log("ACTIVE ->", JSON.stringify(this.activeReservations));
      // console.log("PAST ->", JSON.stringify(this.pastReservations));
    });
  }

  ionViewWillUnload(){
    console.log("unload");
   this.reservationListRef$.unsubscribe();
  }

  ionViewWillLeave(){
    console.log("willLeave");
    this.reservationListRef$.unsubscribe();
   }
   ionViewDidLeave(){
    console.log("didLeave");
    this.reservationListRef$.unsubscribe();
   }

  // goToReservationDetail(params){
  //   if (!params) params = {};
  //   this.navCtrl.push(ReservationDetailPage);
  // }goToAllActiveReservations(params){
  //   if (!params) params = {};
  //   this.navCtrl.push(AllActiveReservationsPage);
  // }
}
