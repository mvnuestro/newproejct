import { UserService } from '../../../providers/user-service';
import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
import { SignupBasicPage } from '../../auth/sign-up-basic/sign-up-basic'
import { SignupPaymentPage } from '../../auth/sign-up-payment/sign-up-payment';
import { TabsPage } from '../../tabs/tabs';
// import { ForgotPasswordPage} from '../../pages/forgot-password/forgot-password';

import { AngularFireAuth } from 'angularfire2/auth';
import {AngularFireDatabase } from 'angularfire2/database';

// import * as firebase from 'firebase/app';
// import { Observable } from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})


export class LoginPage {
  email: string;
  password: string;
  // bankSetup: string;

  constructor(public navCtrl: NavController,
              private afAuth: AngularFireAuth,
              private afDB: AngularFireDatabase,
              private storage: Storage,
              public user: UserService,
              // private alertCtrl: AlertController
            ) {
              storage.get('user')
                .then((data) => {
                  this.email = data;
                }).catch((err) => {
                  console.log("error reading user name from storage");
                });

              storage.get('password')
                .then((data) => {
                  this.password = data;
                }).catch((err) => {
                  console.log("error reading user name from storage");
                });

                // storage.get('bankSetup')
                // .then((data) => {
                //   this.bankSetup = data;
                //   console.log("bank setup complete")
                  
                // }).catch((err) => {
                //   console.log("error reading user name from storage");
                // });

  }

  goToLogin(params){
    if (!params) params = {};

    if (this.email == '' || this.email == null) {
      alert ("Please enter your email");
      return
    } 
    
    if (this.password =='' || this.password == null) {
      alert ("Please enter password");
      return
    } 

    // Login User in Firebase
    this.afAuth
    .auth
    .signInWithEmailAndPassword(this.email, this.password)
    .then(userDetails => {
      console.log('Login Successfull');

      // TODO: Check if this uid exists in Restaurants Node.../Restaurants/'+userDetails.uid
      // If Not, then logout and show an error that user does not exist
      this.afDB.object('/Restaurants/'+userDetails.uid).query
      const userRef$: Observable <any> = this.afDB.object('/Restaurants/'+userDetails.uid).valueChanges();
      
      userRef$.subscribe( afUser =>  {
        if (afUser == null) {
          alert("This email does not exist in our Restaurant Database");
        } else {
          this.user.uid = afUser.uid;
          this.user.paymentacct = afUser.paymentacct;
          this.user.name = afUser.name;
          this.user.owner = afUser.owner;
          this.user.address = afUser.address;
          this.user.city = afUser.city;
          this.user.state = afUser.state;           
          this.user.phone = afUser.phone;
          this.user.zip = afUser.zip;
          this.user.email = afUser.email;
          this.user.banksetup = afUser.banksetup;
          this.user.rate = afUser.rate;
          this.user.profile = afUser.profile;
          this.user.timings = afUser.Timings;
          this.user.agenttype = afUser.agenttype;

          console.log("User found", JSON.stringify(this.user));
          this.storage.set('user',this.email);
          this.storage.set('password',this.password);
          this.goToTabsController(params);
        }
       });

  
    })
    .catch(err => {
      alert("incorrect login");
      console.log('Incorrect Login:',err.message);
    });
  }

  goToSignupBasic(params){
    if (!params) params = {};
    this.navCtrl.push(SignupBasicPage);
  }

  goToForgotPassword(params){
    if (!params) params = {};
    // this.navCtrl.push(ForgotPasswordPage);
  }

  goToTabsController(params){
    if (!params) params = {};
    console.log('check bank setup ->', this.user.banksetup);
    // if (this.user.banksetup == "complete") {
      console.log('Bank Setup is complete')
      this.navCtrl.push(TabsPage);
    // } else {
    //   this.navCtrl.push(SignupPaymentPage, {
    //     'bankMode': 'incomplete'
    //   });
    // }
  }
}
