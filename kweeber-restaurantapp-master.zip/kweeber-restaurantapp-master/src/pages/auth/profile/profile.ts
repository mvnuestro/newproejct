import { Component } from '@angular/core';
import {  NavController, NavParams } from 'ionic-angular'; 
import { UserService } from '../../../providers/user-service';

export class UserObject {
  fname: string;
  lname: string; 
  address: string;
  city: string;
  phone: string;
  email: string;
  password: string
}

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})


export class ProfilePage {
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public user: UserService) {
        console.log("Inside Profile Page");
        console.log("USER PROFILE ->", user);
            
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }

}
