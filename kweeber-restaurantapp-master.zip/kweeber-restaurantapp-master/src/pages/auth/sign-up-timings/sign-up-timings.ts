import { TabsPage } from './../../tabs/tabs';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { UserService } from '../../../providers/user-service'
import * as firebase from 'firebase';
import { SignupPaymentPage} from '../sign-up-payment/sign-up-payment';


/**
 * Generated class for the SignUpTimingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sign-up-timings',
  templateUrl: 'sign-up-timings.html',
})
export class SignupTimingsPage {
  accountMode;
  uid;
  bankMode;
  timings: any;
  btnText = "Save";
  slot11; slot12; slot13; slot14; slot18; slot19; slot20; slot21; slot22;

  constructor(public navCtrl: NavController, 
              public user: UserService,
              public navParams: NavParams) {
  
    console.log("Inside Timings Page");
    this.accountMode = navParams.get("accountMode"); // NEW, UPDATE
    this.bankMode = navParams.get("bankMode"); // NEW, UPDATE
    
    // Get the uid
    if (this.user.uid == null || this.user.uid == ''){
      this.uid = navParams.get("uid"); // Coming from Initial Signup-Basic page
      this.btnText = "Continue";
    } else {
      this.uid = this.user.uid;  // Coming from Login Page
      this.btnText = "Save";
      this.timings = this.user.timings;
      console.log("Timings ->", this.timings["11"]);
      this.slot11 = this.timings["11"]; 
      this.slot12 = this.timings["12"]; 
      this.slot13 = this.timings["13"]; 
      this.slot14 = this.timings["14"];  
      this.slot18 = this.timings["18"];  
      this.slot19 = this.timings["19"];  
      this.slot20 = this.timings["20"];  
      this.slot21 = this.timings["21"];  
      this.slot22 = this.timings["22"]; 
      
    }

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignUpTimingsPage');
  }

  goToSignupBank(params){
    if (!params) params = {};

    // validate timings data
    if (this.slot11 == '' || this.slot11 == null ) {
      this.slot11 = 0;
    }
    if (this.slot12 == '' || this.slot12 == null ) {
      this.slot12 = 0;
    }
    if (this.slot13 == '' || this.slot13 == null ) {
      this.slot13 = 0;
    }
    if (this.slot14 == '' || this.slot14 == null ) {
      this.slot14 = 0;
    }
    if (this.slot18 == '' || this.slot18 == null ) {
      this.slot18 = 0;
    }
    if (this.slot19 == '' || this.slot19 == null ) {
      this.slot19 = 0;
    }
    if (this.slot20 == '' || this.slot20 == null ) {
      this.slot20 = 0;
    }
    if (this.slot21 == '' || this.slot21 == null ) {
      this.slot21 = 0;
    }
    if (this.slot22 == '' || this.slot22 == null ) {
      this.slot22 = 0;
    }

    // Check if slots are more than 99
    if (this.slot11 > 99 || this.slot12 > 99 || this.slot13 > 99 || this.slot14 > 99 || 
      this.slot18 > 99 || this.slot19 > 99 || this.slot20 > 99 || this.slot21 > 99 || this.slot22 > 99 ) {
        console.log("more than 99 slots");
        alert('Maximum 99 reservations are allowed for any one slot. Please correct!');
        return;
    }

    // Save Timings data in Firebase
      firebase.database().ref().child('Restaurants').child(this.uid).child('Timings').update({
        11: this.slot11,
        12: this.slot12,
        13: this.slot13,
        14: this.slot14,
        18: this.slot18,
        19: this.slot19,
        20: this.slot20,
        21: this.slot21,
        22: this.slot22
       }).then((success)=> {
         if (this.accountMode == 'new') {
            this.navCtrl.push(SignupPaymentPage, {
              'bankMode': this.bankMode,
              'uid': this.uid
            });
         } else {
            this.navCtrl.push(TabsPage);
         }

          // this.navCtrl.push(SignupPaymentPage, {
          //   'bankMode': 'new',
          //   'uid': userDetails.uid
          // });
       }).catch ((error) => {
         alert ("Error Storing Profile")
       })
    // })
  }
}
