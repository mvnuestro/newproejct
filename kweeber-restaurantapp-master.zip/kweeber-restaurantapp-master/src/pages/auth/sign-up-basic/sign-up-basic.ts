import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { UserService } from '../../../providers/user-service';
import { SignupPaymentPage} from '../sign-up-payment/sign-up-payment';
import { SignupTimingsPage} from '../sign-up-timings/sign-up-timings';

import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase';

@Component({
  selector: 'page-sign-up-basic',
  templateUrl: 'sign-up-basic.html'
})


export class SignupBasicPage {
  
  confirmPassword: string;
  constructor(public navCtrl: NavController,
              private afAuth: AngularFireAuth,
              public user: UserService,
              ) {

            
  }

  goToLogin(params){
    if (!params) params = {};
    this.navCtrl.push(LoginPage);
  }
  
  goToTimings(params){
    if (!params) params = {};

    // Make all fields required
    if (this.user.name == '' || this.user.name == null) {
      alert ("Please enter Restaurant name");
      return
    }

    if (this.user.owner == '' || this.user.owner == null) {
      alert ("Please enter Owner name");
      return
    }

    if (this.user.address == '' || this.user.address == null) {
      alert ("Please enter your address");
      return
    }

    if (this.user.city == '' || this.user.city == null) {
      alert ("Please enter your city");
      return
    }

    if (this.user.phone == '' || this.user.phone == null) {
      alert ("Please enter your phone number");
      return
    }
    
    if (this.user.zip == '' || this.user.zip == null) {
      alert ("Please enter your zip code");
      return
    }

    if (this.user.email == '' || this.user.email == null) {
      alert ("Please enter email");
      return
    } 

    if (this.user.password == '' || this.user.password == null) {
      alert ("Please enter password");
      return
    } 

    if (this.user.password != this.confirmPassword ) {
      alert ("Password does not match");
      return
    } 

    // Login User in Firebase
    this.afAuth
    .auth
    .createUserWithEmailAndPassword(this.user.email, this.user.password)
    .then(userDetails => {
      console.log('Account Created Successfully', JSON.stringify(userDetails));
      // Store account information in firebase

      firebase.database().ref().child('Restaurants').child(userDetails.uid).set({
        // date: firebase.database.ServerValue.TIMESTAMP,
        uid: userDetails.uid,
        name: this.user.name,
        owner: this.user.owner,
        address: this.user.address, 
        city: this.user.city,
        state: this.user.state,
        zip: this.user.zip,
        phone: this.user.phone,
        email: this.user.email,
        banksetup: 'incomplete'
        // rate: this.user.rate,
        // profile: this.user.profile
       }).then((success)=> {
          this.navCtrl.push(SignupTimingsPage, {
            'accountMode': 'new',
            'bankMode': 'new',
            'uid': userDetails.uid
          });
          // this.navCtrl.push(SignupPaymentPage, {
          //   'bankMode': 'new',
          //   'uid': userDetails.uid
          // });
       }).catch ((error) => {
         alert ("Error Storing Profile")
       })
      // this.storage.set('user',this.email);
      // this.storage.set('password',this.password);
      // this.navCtrl.push(SignupBankPage);

    })
    .catch(err => {
      alert(err.message);
      console.log('Error creating account',err.message);
    });
  }
}

