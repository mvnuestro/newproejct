import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LoginPage } from '../login/login';

import { UserService } from '../../../providers/user-service'
import { PaymentService } from '../../../providers/payment-service'

import { UtilityService } from '../../../providers/utility-service';
import * as firebase from 'firebase';

@Component({
  selector: 'page-signup-payment',
  templateUrl: 'sign-up-payment.html'
})
export class SignupPaymentPage {
  setupBankTitle: string = 'Setup Bank';
  mode: string; // NEW, INCOMPLETE, DISPLAY
  bankName: string;
  bankRouting: string = '110000000';
  accNumber: string = '000123456789';
  confirmAccNumber: string;
  countryCode: string = "US";
  accountType: string = "individual";
  uid;
  constructor(public navCtrl: NavController,
              // private storage: Storage,
              public navParams: NavParams,
              public user: UserService,
              private utilityService: UtilityService,
              private paymentService: PaymentService 
            ) {

    this.mode = navParams.get("bankMode"); // NEW, INCOMPLETE, DISPLAY
    if (this.mode == 'display') {

      console.log(JSON.stringify(user));
      // Retrieve bank information from Stripe
      this.paymentService.getBankInfo(user.paymentacct).then ( (paymentData: any) => {
        paymentData.external_accounts.data.forEach(bankData => {
          console.log("Bank Account", JSON.stringify(bankData));
          this.bankRouting = bankData.routing_number;
          this.bankName = bankData.bank_name;
          this.setupBankTitle = 'Bank Details';
        })
        // let agentInfo = JSON.parse(data);

        // console.log("Found Payment Data", JSON.stringify(paymentData));
      }).catch (error => {
        console.log("Agent Account Retrieve Error", JSON.stringify(error));
      })
    }

    // Get the uid
    if (this.user.uid == null || this.user.uid == ''){
      this.uid = navParams.get("uid"); // Coming from Initial Signup-Basic page
    } else {
      this.uid = this.user.uid;  // Coming from Login Page
    }
  } 

  goToSkip() {
    this.navCtrl.push(LoginPage);
  }

  goToLogin(params){
    if (!params) params = {};
   
    if (this.bankName == '' || this.bankName == null) {
      alert ("Please enter your bank name");
      return
    }

    if (this.bankRouting == '' || this.bankRouting  == null) {
      alert ("Please enter your routing number");
      return
    }

    if (this.accNumber == '' || this.accNumber == null) {
      alert ("Please enter your account number");
      return
    }

    if (this.confirmAccNumber == '' || this.confirmAccNumber == null) {
      alert ("Please confirm your account number");
      return
    }

    if (this.countryCode == '' || this.countryCode == null) {
      alert ("Please enter your Country Code");
      return
    }

    // Call payment service to create account
    let acctEmail = 'email=' + this.user.email;
    acctEmail += '&type=custom';
    acctEmail += '&country=US';
    acctEmail += '&business_name='+this.user.name;
    acctEmail += '&legal_entity[type]=' + this.accountType;
    acctEmail += '&legal_entity[first_name]='+this.user.name;
    // acctEmail += '&legal_entity[last_name]='+this.user.lname;
    // acctEmail += '&legal_entity[dob][day]=31';
    // acctEmail += '&legal_entity[dob][month]=01';
    // acctEmail += '&legal_entity[dob][year]=1975';
    // acctEmail += '&legal_entity[address][city]=San Jose';
    // acctEmail += '&legal_entity[address][line1]=5666 Silver Creek Valley Road';
    // acctEmail += '&legal_entity[address][postal_code]=95138';
    // acctEmail += '&legal_entity[address][state]=CA';
    // acctEmail += '&legal_entity[address][country]=US';
    // acctEmail += '&legal_entity[ssn_last_4]=8555';
    // acctEmail += '&legal_entity[ssn]=445768555';
    // acctEmail += '&legal_entity[dob][ssn]=31';
  
    let acctParams = {
      routing_number: this.bankRouting,
      account_number: this.accNumber,
      currency: "USD",
      country: "US",
      account_holder_name: this.user.owner,
      account_holder_type: this.accountType,
    }
    
    console.log("Calling payment service");
    this.paymentService.createAccount(acctEmail, acctParams ).then ((result) => {
      // Save BankSetup Complete data in firebase
      console.log("Payment Service Response ->",result);
      console.log("User ->", this.uid);
      firebase.database().ref().child('Agents').child(this.uid).update({
        banksetup: 'complete',
        paymentacct: result
       });
       console.log('Bank Setup is complete')
      //  this.navCtrl.push(TabsControllerPage);
       this.navCtrl.push(LoginPage);
       
    }).catch ((error) => {
      // Show the error message
      this.utilityService.showErrorAlert('Setup Payment Error',error)
    });
  }
}

