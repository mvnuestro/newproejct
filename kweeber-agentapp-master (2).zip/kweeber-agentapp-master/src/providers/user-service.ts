import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
    uid: string;
    paymentacct: string;
    fname: string;
    lname: string; 
    address: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    email: string;
    password: string;
    banksetup: string;
    rate: string;
    profile: string;
    restaurants: any;

  constructor() {
      
  }

  clear(){
    this.uid = '';
    this.paymentacct = '';
    this.fname = '';
    this.lname = '';
    this.address = '';
    this.city = '';
    this.state = '';
    this.zip = '';
    this.phone = '';
    this.email = '';
    this.password = '';
    this.banksetup = '';
    this.rate = '';
    this.profile = '';
  }
}