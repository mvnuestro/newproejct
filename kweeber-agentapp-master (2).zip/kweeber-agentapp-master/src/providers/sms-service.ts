import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AlertController } from 'ionic-angular';

/*
  Generated class for the TwilloProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class TwilloProvider {

	customerPhone: string;
	
	constructor(public http: HttpClient, private alertCtrl: AlertController) {
		console.log('Hello TwilloProvider Provider');
	}

	fnSendSms(data,headerObject,accountSID) {
		return new Promise((resolve, reject) => {
			let url = "https://api.twilio.com/2010-04-01/Accounts/" + accountSID + "/Messages.json?" + data;
			console.log(url)
			this.http.post(url, data,
				{
					headers: headerObject
				})
				.subscribe((result: any) => {
					if (result.message) {
						let alert = this.alertCtrl.create({
							title: result.message,
							buttons: ['Dismiss']
						});
						alert.present();
					}
					resolve(result);
				}, (error: any) => {
					console.log(error)
					if (error.error.message) {
						let alert = this.alertCtrl.create({
							title: error.error.message,
							buttons: ['Dismiss']
						});
						alert.present();
					}
					reject(error);
				})
		})
	}
}
