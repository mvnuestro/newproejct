// import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Http, Headers } from '@angular/http';

/*
  Generated class for the CustomeHttpServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class HttpService {

  constructor(public http: Http) {
  }
  post_new(url, data) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      headers.append('Authorization', 'Bearer sk_test_fUjnPUzsZCApMLDCopA37cGB');

      this.http.post(url, data, { headers: headers }).subscribe((result: any) => {
        result = result.json();
        resolve(result)
      }, (error: any) => {
        reject(error)
      })
    })
  }
}
