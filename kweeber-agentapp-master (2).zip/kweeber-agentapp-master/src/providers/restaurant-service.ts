import { Injectable } from '@angular/core';

@Injectable()
export class RestaurantService {
    uid: string;
    name: string;
    owner: string; 
    phone: string;
    timeslots: [{
        time: string,
        slots: string
    }]

  constructor() {   
  }
}

export class ReservationService {
    id: string;
    fname: string;
    lname: string;
    phone: string;
    email: string;
    persons: string;
    date: string;
    timeslot: string;

    constructor() {
        
    }

  }

export class RestaurantTableService {
    id: string;
    date: string;
    availableTimeslots: [{
        time: string,
        slots: string
    }]
  constructor() {
      
  }

}


