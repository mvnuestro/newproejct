import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SelectRestaurantPage } from '../select-restaurant/select-restaurant';
import { AllActiveReservationsPage } from '../reservations/all-active-reservations/all-active-reservations';
import { AllMessagesPage } from '../messages/all-messages/all-messages';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {

  tab1Root: any = SelectRestaurantPage;
  tab2Root: any = AllActiveReservationsPage;
  tab3Root: any = AllMessagesPage;
  constructor(public navCtrl: NavController) {
  }
  
}
