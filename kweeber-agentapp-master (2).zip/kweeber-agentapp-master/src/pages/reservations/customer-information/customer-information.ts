import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ReserveTablePage } from '../reserve-table/reserve-table';
// import { ConfirmReservationPage } from '../confirm-reservation/confirm-reservation';
// import { YourReservationPage } from '../your-reservation/your-reservation';
// import { SelectRestaurantPage } from '../../select-restaurant/select-restaurant';
// import { reservationInformationPage } from '../reservation-information/reservation-information';
import { RestaurantService, ReservationService } from '../../../providers/restaurant-service';



@Component({
  selector: 'page-customer-information',
  templateUrl: 'customer-information.html'
})

export class CustomerInformationPage {
  restaurant: RestaurantService;
  reservation: ReservationService;
  masks: any;
  constructor(public navCtrl: NavController,
              public navParams: NavParams) {
      this.masks = {
        phoneNumber: ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/],
      };
      this.reservation = new ReservationService;
      this.restaurant = new RestaurantService;
      this.restaurant = navParams.get("restaurant");  
      console.log("FROM reservation", JSON.stringify(this.restaurant));
  }
  
  goToReserveTable(params){
    if (!params) params = {};

    if (this.reservation.lname == '' || this.reservation.lname == null) {
      alert ("Please enter Last name");
      return false
    }

    if (this.reservation.phone == '' || this.reservation.phone == null) {
      alert ("Please enter Phone to send confirmation");
      return false
    }

		if (this.reservation.phone.length < 10) {
      alert ("Please enter valid Phone Number");
      return false      
    }

    this.reservation.date = '';
    this.reservation.timeslot = '';
    this.reservation.persons = '';
    this.navCtrl.push(ReserveTablePage,{
      'restaurant': this.restaurant,
      'reservation': this.reservation
    });
  }
}
