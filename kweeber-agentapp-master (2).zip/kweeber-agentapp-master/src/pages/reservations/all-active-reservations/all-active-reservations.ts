import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
// import { ReservationDetailPage } from '../reservation-detail/reservation-detail';
// import { AllActiveReservationsPage } from '../all-active-reservations/all-active-reservations';
import { RestaurantService, ReservationService } from '../../../providers/restaurant-service';
import {AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
// import * as firebase from 'firebase';
import { UserService } from '../../../providers/user-service';
import * as moment from 'moment';
@Component({
  selector: 'page-all-active-reservations',
  templateUrl: 'all-active-reservations.html'
})
export class AllActiveReservationsPage {
  restaurants = [];
  reservations = [];
  constructor(public navCtrl: NavController,
              public reservation: ReservationService,

              public restaurant: RestaurantService,
              private afDB: AngularFireDatabase,
              public user: UserService) {
      console.log("========>>>>> IN RESERVATION <<<<<<<========== ")
      const restaurantListRef$: Observable <any> = this.afDB.list('/Restaurants').valueChanges();
      restaurantListRef$.subscribe( afRrestaurantList =>  {
        afRrestaurantList.forEach(afRestaurant => {
          restaurant = afRestaurant;
          this.restaurants.push(restaurant);
        });
        // console.log(JSON.stringify(this.restaurants));
      });
  }

  ionViewWillEnter(){
    this.reservations = [];
    let tDate = String(moment(new Date()).format('YYYY-MM-DD'));

    const reservationListRef$: Observable <any> = this.afDB.list('/Reservations').valueChanges();
    reservationListRef$.subscribe( afReservationList =>  {
      afReservationList.forEach(afReservation => {
        if (afReservation.agentid == this.user.uid && afReservation.date >= tDate ){
          this.reservations.push(afReservation);
        }
      });
      console.log(JSON.stringify(this.reservations));
    });
  }

}
