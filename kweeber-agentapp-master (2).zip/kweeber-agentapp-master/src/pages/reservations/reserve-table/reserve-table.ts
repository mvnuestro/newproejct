import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConfirmReservationPage } from '../confirm-reservation/confirm-reservation';
import { ReservationService } from '../../../providers/restaurant-service';

@Component({
  selector: 'page-reserve-table',
  templateUrl: 'reserve-table.html'
})
export class ReserveTablePage {

  restaurant: any;
  reservation: ReservationService;
  timeslots = [];

  constructor(public navCtrl: NavController,
              public navParams: NavParams) {

      this.reservation = new ReservationService;
      this.restaurant = navParams.get("restaurant");  
      this.reservation = navParams.get("reservation");  
      
      // this.restaurant.Timings.forEach(element => {
      //   console.log("element",element);
      //   // this.timeslots.push(element.time);
      // });

      if (this.restaurant.Timings["11"] > 0) {
         this.timeslots.push({ time:"11", slots:Number(this.restaurant.Timings["11"]) });
      }
      
      if (this.restaurant.Timings["12"] > 0) {
         this.timeslots.push({ time:"12", slots:Number(this.restaurant.Timings["12"]) });
      }

      if (this.restaurant.Timings["13"] > 0) {
        this.timeslots.push({ time:"13", slots:Number(this.restaurant.Timings["13"]) });
      }
      
      if (this.restaurant.Timings["14"] > 0) {
        this.timeslots.push({ time:"14", slots:Number(this.restaurant.Timings["14"]) });
      }
      
      if (this.restaurant.Timings["18"] > 0) { 
        this.timeslots.push({ time:"18", slots:Number(this.restaurant.Timings["18"]) });   
      }
      
      if (this.restaurant.Timings["19"] > 0) {
        this.timeslots.push({ time:"19", slots:Number(this.restaurant.Timings["19"]) });   
      }
      
      if (this.restaurant.Timings["20"] > 0) {
        this.timeslots.push({ time:"20", slots:Number(this.restaurant.Timings["20"]) }); 
      }
      
      if (this.restaurant.Timings["21"] > 0) {
        this.timeslots.push({ time:"21", slots:Number(this.restaurant.Timings["21"]) });
      }
      
      if (this.restaurant.Timings["22"] > 0) {
        this.timeslots.push({ time:"22", slots:Number(this.restaurant.Timings["22"]) });
      }
             
      console.log("Timeslots Array ->", this.timeslots);  
      // this.timeslots = this.restaurant.timeslots;
      
  }
  goToConfirmReservation(params){
    if (!params) params = {};

    // Validate data
    if (this.reservation.persons == '' || this.reservation.persons == null) {
      alert ("Please enter No of Persons");
      return
    }

    if (this.reservation.date == '' || this.reservation.date == null) {
      alert ("Please select Date");
      return
    }

    if (this.reservation.timeslot == '' || this.reservation.timeslot == null) {
      alert ("Please select TimeSlot");
      return
    }

    // Navigate to next page


    this.navCtrl.push(ConfirmReservationPage, {
      'restaurant': this.restaurant,
      'reservation': this.reservation
    });
  }
}
