import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
// import { YourReservationPage } from '../your-reservation/your-reservation';
import { SelectRestaurantPage } from '../../select-restaurant/select-restaurant';
// import { CustomerInformationPage } from '../customer-information/customer-information';
// import { ReserveTablePage } from '../reserve-table/reserve-table';
// import { ConfirmReservationPage } from '../confirm-reservation/confirm-reservation';
import { RestaurantService, ReservationService } from '../../../providers/restaurant-service';
import {AngularFireDatabase } from 'angularfire2/database';
// import { Observable } from 'rxjs/Observable';
import * as firebase from 'firebase';
import { UserService } from '../../../providers/user-service';
import { TwilloProvider } from '../../../providers/sms-service';

@Component({
  selector: 'page-confirm-reservation',
  templateUrl: 'confirm-reservation.html'
})
export class ConfirmReservationPage {
  twillioConfigData;
  twilioHeader: any;
  showContent: boolean = false;
  pleaseWait: boolean = false;
  
  constructor(
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public reservation: ReservationService,
    public restaurant: RestaurantService,
    private afDB: AngularFireDatabase,
    public navParams: NavParams,
    private twilio: TwilloProvider,    
    public user: UserService) {
      // Retrieve nav content 
      this.restaurant = navParams.get("restaurant");
      this.reservation = navParams.get("reservation");
      console.log("Restaurant)", this.restaurant);

      // get users twilio authentication data from firebase
      this.afDB.list('/configs').valueChanges().subscribe((result: any) => {
        this.twillioConfigData = result
        if (this.twillioConfigData && this.twillioConfigData.length > 0){
          // select latest record from firebase
          this.twillioConfigData = this.twillioConfigData[0] 
          
          // twilio auth header
          this.twilioHeader = {
            'Authorization': "Basic " + btoa(this.twillioConfigData.accountSID + ":" + this.twillioConfigData.authToken),
            "Content-Type": "application/x-www-form-urlencoded"
          }
          this.showContent =true;
        } else {
          //error if data not found in firebase
          let alert = this.alertCtrl.create({
              title: 'SMS Configuration Missing',
              buttons: ['Dismiss']
          });
          alert.present();  
        }
      },(error)=>{
        //error if not connecting to internet
        let alert = this.alertCtrl.create({
                title: 'Please connect to Internet',
                buttons: ['Dismiss']
        });
        alert.present();
      })
    }

  cancel(){
    // this.reservation = null;
    this.navCtrl.push(SelectRestaurantPage);
  }

  goToSelectRestaurant(params){
    if (!params) params = {};

    this.reservation.id = String(Math.floor(Math.random() * 1000000) + 1000000) ;
    if (this.reservation.email == null) {
      this.reservation.email = '';
    }
    if (this.reservation.fname == null) {
      this.reservation.fname = '';
    }
    if (this.reservation.lname == null) {
      this.reservation.lname = '';
    }
    if (this.reservation.phone == null) {
      this.reservation.phone = '';
    }

    console.log("RESTAURANT ->", this.restaurant);
    console.log("RESERVATION ->", this.reservation);

    // Save reservation in the database
    // firebase.database().ref().child('Reservations').child(this.restaurant.id).child(this.reservation.date).child(this.reservation.id).set({
    firebase.database().ref().child('Reservations').child(this.reservation.id).update({
      restaurantid: this.restaurant.uid,
      restaurantname: this.restaurant.name,
      reservationid: this.reservation.id,
      agentid: this.user.uid,
      agentname: this.user.fname + ' ' + this.user.lname,
      fname: this.reservation.fname,
      lname: this.reservation.lname,
      email: this.reservation.email,
      persons: this.reservation.persons,
      date: this.reservation.date,
      timeslot: this.reservation.timeslot
     }).then (val => {

      // Send the SMS to customer phone
      this.sendSMS();

      // // Navigate to select restaurant page
      // this.navCtrl.popToRoot(); 
     }).catch ((err) => {
       alert(err.description);
     })
  }

  sendSMS() {

    //let phonenofrom = this.userData.from;
    let phoneFrom = this.twillioConfigData.from;
    
    console.log('Phone From - ', phoneFrom);
    console.log('Phone To - ', this.reservation.phone);
    this.pleaseWait = true;
    let msg = 'Your reservation for ' + this.reservation.persons + ' persons is confirmed at '+ this.restaurant.name + ' for ' + this.reservation.date + ' @' + this.reservation.timeslot + ":00 ";
    let d = "To=" + encodeURIComponent(this.reservation.phone) +
            "&From=" + encodeURIComponent(phoneFrom) +
            "&Body=" + encodeURIComponent(msg)

 

    //send text via twilio
    this.twilio.fnSendSms(d,this.twilioHeader,this.twillioConfigData.accountSID).then((result: any) => {
            //insert data in firebase
            // this.afDB.database.ref().child('orders').push(insertObject);
            // this.msg = '';
            // this.phoneNo = '';
            let alert = this.alertCtrl.create({
                    title: 'Reservation Confirmed',
                    buttons: ['Dismiss']
            });
            alert.present().then ((msg) => {
              this.pleaseWait = false;
              
              // Navigate to select restaurant page
              this.navCtrl.popToRoot(); 
            });
            
    }, (error: any) => {
            //show error if some error in twilio
            this.pleaseWait = false;
            // this.msg = '';
            // this.phoneNo = '';
            console.log(error)
            // Navigate to select restaurant page
            this.navCtrl.popToRoot(); 
    })
  }
}
