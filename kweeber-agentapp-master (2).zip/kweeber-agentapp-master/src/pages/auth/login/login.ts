
import { UserService } from '../../../providers/user-service';
import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
import { SignupBasicPage } from '../signup-basic/signup-basic';
import { SignupBankPage } from '../signup-bank/signup-bank';
import { TabsControllerPage } from '../../tabs-controller/tabs-controller';
import { ForgotPasswordPage} from '../forgot-password/forgot-password';

import { AngularFireAuth } from 'angularfire2/auth';
import {AngularFireDatabase } from 'angularfire2/database';

import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  email: string;
  password: string;
  // bankSetup: string;

  constructor(public navCtrl: NavController,
              private afAuth: AngularFireAuth,
              private afDB: AngularFireDatabase,
              private storage: Storage,
              public user: UserService,
              // private alertCtrl: AlertController
            ) {
              storage.get('user')
                .then((data) => {
                  this.email = data;
                }).catch((err) => {
                  console.log("error reading user name from storage");
                });

              storage.get('password')
                .then((data) => {
                  this.password = data;
                }).catch((err) => {
                  console.log("error reading user name from storage");
                });

                // storage.get('bankSetup')
                // .then((data) => {
                //   this.bankSetup = data;
                //   console.log("bank setup complete")
                  
                // }).catch((err) => {
                //   console.log("error reading user name from storage");
                // });

  }

  goToLogin(params){
    if (!params) params = {};

    if (this.email == '' || this.email == null) {
      alert ("Please enter your email");
      return
    } 
    
    if (this.password =='' || this.password == null) {
      alert ("Please enter password");
      return
    } 

    // Login User in Firebase
    this.afAuth
    .auth
    .signInWithEmailAndPassword(this.email, this.password)
    .then(userDetails => {
      console.log('Login Successfull');
      const userRef$: Observable <any> = this.afDB.object('/Agents/'+userDetails.uid).valueChanges();
      userRef$.subscribe( afUser =>  {
          if (afUser == null) {
              alert("This email does not exist in our Agent Database");
          } else {
            this.user.uid = afUser.uid;
            this.user.paymentacct = afUser.paymentacct;
            this.user.fname = afUser.fname;
            this.user.lname = afUser.lname;
            this.user.address = afUser.address;
            this.user.city = afUser.city;
            this.user.state = afUser.state;           
            this.user.phone = afUser.phone;
            this.user.zip = afUser.zip;
            this.user.email = afUser.email;
            this.user.banksetup = afUser.banksetup;
            this.user.rate = afUser.rate;
            this.user.profile = afUser.profile;
            this.user.restaurants = afUser.restaurants;
            console.log("User found", JSON.stringify(this.user.uid));
            this.storage.set('user',this.email);
            this.storage.set('password',this.password);
            this.goToTabsController(params);
          }
       });

  
    })
    .catch(err => {
      alert("incorrect login");
      console.log('Incorrect Login:',err.message);
    });
  }

  goToSignupBasic(params){
    if (!params) params = {};
    this.navCtrl.push(SignupBasicPage);
  }

  goToForgotPassword(params){
    if (!params) params = {};
    this.navCtrl.push(ForgotPasswordPage);
  }

  goToTabsController(params){
    if (!params) params = {};
    console.log('check bank setup ->', this.user.banksetup);
    if (this.user.banksetup == "complete") {
      console.log('Bank Setup is complete')
      this.navCtrl.push(TabsControllerPage);
    } else {
      this.navCtrl.push(SignupBankPage, {
        'bankMode': 'incomplete'
      });
    }
  }
}
