import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { SignupBasicPage } from '../signup-basic/signup-basic';
import { SignupBankPage } from '../signup-bank/signup-bank';

@Component({
  selector: 'page-forgot-password',
  templateUrl: 'forgot-password.html'
})
export class ForgotPasswordPage {

  constructor(public navCtrl: NavController) {
  }
  goToLogin(params){
    if (!params) params = {};
    this.navCtrl.push(LoginPage);
  }goToSignupBasic(params){
    if (!params) params = {};
    this.navCtrl.push(SignupBasicPage);
  }goToSignupBank(params){
    if (!params) params = {};
    this.navCtrl.push(SignupBankPage);
  }
}
