import { UserService } from './../../providers/user-service';
import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CustomerInformationPage } from '../reservations/customer-information/customer-information';
// import { ReserveTablePage } from '../reservations/reserve-table/reserve-table';
// import { ConfirmReservationPage } from '../reservations/confirm-reservation/confirm-reservation';
// import { YourReservationPage } from '../reservations/your-reservation/your-reservation';
// import { SelectRestaurantPage } from '../select-restaurant/select-restaurant';
// import { Restaurant } from '../../data/restaurant.interface';
// import restaurants from '../../data/restaurants';
import {AngularFireDatabase } from 'angularfire2/database';
import { RestaurantService } from '../../providers/restaurant-service';
import { Observable } from 'rxjs/Observable';



@Component({
  selector: 'page-select-restaurant',
  templateUrl: 'select-restaurant.html'
})
export class SelectRestaurantPage implements OnInit {
  restaurants = [];


  ngOnInit() {
    // this.restaurantList = restaurants;
  }

  constructor(public navCtrl: NavController,
              private afDB: AngularFireDatabase,
              public user: UserService,
              public restaurant: RestaurantService) {
        const restaurantListRef$: Observable <any> = this.afDB.list('/Restaurants').valueChanges();
        console.log("Select-Restaurant Page - User Info ->", JSON.stringify(user));

        if (user.restaurants != null) {
          console.log("This agent has been hired by some Restaurants", JSON.stringify(user.restaurants));
          let myRestaurants = Object.keys(user.restaurants).map(e=>user.restaurants[e]);
          if (myRestaurants != null) {
            console.log("Restaurants found", JSON.stringify(myRestaurants));

            restaurantListRef$.subscribe( afRrestaurantList =>  {
              console.log("Inside Restaurant subscription");
              afRrestaurantList.forEach(afRestaurant => {
                myRestaurants.forEach(myRestaurant => {
                  if (afRestaurant.uid == myRestaurant.restaurantid) {
                    restaurant = afRestaurant;
                    this.restaurants.push(restaurant);
                  }                
                });
              });
              console.log("My Restaurants ---> ", JSON.stringify(this.restaurants));
            });
          }
        }

  }
  goToCustomerInformation(params){
    if (!params) params = {};
    this.navCtrl.push(CustomerInformationPage, {
      'restaurant': params
    });

  }
  
}
