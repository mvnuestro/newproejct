import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MessagePage } from '../message/message';

@Component({
  selector: 'page-all-messages',
  templateUrl: 'all-messages.html'
})
export class AllMessagesPage {

  constructor(public navCtrl: NavController) {
  }
  goToMessage(params){
    if (!params) params = {};
    this.navCtrl.push(MessagePage);
  }
}
