export default [ 
    {
      restaurants: [ 
        {
          id: '1',
          restaurant: 'ABC Restaurant',
          text: 'Italian Food'
        },
        {
            id: '2',
            restaurant: 'DEF Restaurant',
            text: 'Burgers and Hotdogs'
        },
        {
            id: '3',
            restaurant: 'ABC Restaurant',
            text: 'Thai Cusine'
        }

    ]
        
       
    }
];
