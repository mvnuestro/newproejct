export interface Restaurant {
    id: string;
    restaurant: string;
    text: string;
}