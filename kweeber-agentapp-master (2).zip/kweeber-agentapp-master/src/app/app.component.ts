import { Component, ViewChild } from '@angular/core';
import { Platform, Nav, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Keyboard } from '@ionic-native/keyboard';
import { AngularFireAuth } from 'angularfire2/auth';
import { ProfilePage } from '../pages/auth/profile/profile';
import { SignupBankPage } from '../pages/auth/signup-bank/signup-bank';
import { UserService } from '../providers/user-service';
 

// import * as firebase from 'firebase/app';

import { LoginPage } from '../pages/auth/login/login';
// import { MenuClose } from 'ionic-angular/components/menu/menu-close';
import { MenuController } from 'ionic-angular';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
    rootPage:any = LoginPage;

  constructor(platform: Platform, 
              statusBar: StatusBar, 
              splashScreen: SplashScreen,
              public alertCtrl: AlertController,
              private afAuth: AngularFireAuth,
              public user: UserService,
              public menuCtrl: MenuController,
              public keyboard: Keyboard) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
      keyboard.hideKeyboardAccessoryBar(false);
    });
    
  }

      showLogout() {
        console.log
        let alert = this.alertCtrl.create({
          title: 'Confirm Log Out',
          message: 'Are you sure you want to log out?',
          buttons: [
            {
              text: 'No',
              role: 'cancel',
              handler: () => {
                this.menuCtrl.close();
                console.log('Cancel clicked');
              }
            },
            {
              text: 'Yes',
              handler: () => {
              console.log('Logged out');

              this.afAuth
              .auth.signOut()
              .then (value => {
                console.log('Logout Successfull');
                this.user.clear();
                this.menuCtrl.close();
                // navigate to login
                this.navCtrl.push(LoginPage);
                // close the side menu
              })
              .catch(err => {
            
                console.log('logout error:',err.message);
              });

            }
            }
          ]
        });
        
        alert.present();
      
      }

      goToProfilePage() {
        this.navCtrl.push(ProfilePage);
        this.menuCtrl.close();
      }
      
      goToBankPage() {
        this.navCtrl.push(SignupBankPage, {
          'bankMode': 'display'
        });
        this.menuCtrl.close();
      }
      
}
