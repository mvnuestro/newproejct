import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { SelectRestaurantPage } from '../pages/select-restaurant/select-restaurant';
import { AllActiveReservationsPage } from '../pages/reservations/all-active-reservations/all-active-reservations';
import { AllMessagesPage } from '../pages/messages/all-messages/all-messages';
import { MessagePage } from '../pages/messages/message/message';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { LoginPage } from '../pages/auth/login/login';
import { SignupBasicPage } from '../pages/auth/signup-basic/signup-basic';
import { SignupBankPage } from '../pages/auth/signup-bank/signup-bank';
import { ProfilePage } from '../pages/auth/profile/profile';

import { ForgotPasswordPage } from '../pages/auth/forgot-password/forgot-password';
import { CustomerInformationPage } from '../pages/reservations/customer-information/customer-information';
import { ReserveTablePage } from '../pages/reservations/reserve-table/reserve-table';
import { ConfirmReservationPage } from '../pages/reservations/confirm-reservation/confirm-reservation';
// import { YourReservationPage } from '../pages/reservations/your-reservation/your-reservation';
// import { ReservationDetailPage } from '../pages/reservations/reservation-detail/reservation-detail';

import { AngularFireModule } from 'angularfire2' ;
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { IonicStorageModule } from '@ionic/storage';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Keyboard } from '@ionic-native/keyboard';

import { ParallaxDirective }  from '../directives/parallax/parallax';
import { UserService } from '../providers/user-service';
import { UtilityService } from '../providers/utility-service';

import { PaymentService } from '../providers/payment-service';
import { HttpService } from '../providers/http-service';
import { RestaurantService, ReservationService } from '../providers/restaurant-service';
import { Stripe } from '@ionic-native/stripe';
import { TextMaskModule } from 'angular2-text-mask';
import { TwilloProvider } from '../providers/sms-service';

// import { HTTP } from '@ionic-native/http';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

  var firebaseConfig = {
    apiKey: "AIzaSyDvsJ-LRFtL8RLQPtEN9sWvia2kx3uhSIU",
    authDomain: "kweeber-9575e.firebaseapp.com",
    databaseURL: "https://kweeber-9575e.firebaseio.com",
    projectId: "kweeber-9575e",
    storageBucket: "",
    messagingSenderId: "993450317354"
  };

@NgModule({
  declarations: [
    MyApp,
    SelectRestaurantPage,
    AllActiveReservationsPage,
    AllMessagesPage,
    MessagePage,
    TabsControllerPage,
    LoginPage,
    SignupBasicPage,
    SignupBankPage,
    ForgotPasswordPage,
    CustomerInformationPage,
    ReserveTablePage,
    ConfirmReservationPage,
    // YourReservationPage,
    // ReservationDetailPage,
    ProfilePage,
    ParallaxDirective
  ],
  imports: [
    BrowserModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    TextMaskModule,
    HttpClientModule,
    HttpModule,
    IonicStorageModule.forRoot(),
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    SelectRestaurantPage,
    AllActiveReservationsPage,
    AllMessagesPage,
    MessagePage,
    TabsControllerPage,
    LoginPage,
    SignupBasicPage,
    SignupBankPage,
    ForgotPasswordPage,
    CustomerInformationPage,
    ReserveTablePage,
    ConfirmReservationPage,
    // YourReservationPage,
    // ReservationDetailPage,
    ProfilePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Keyboard,
    UserService,
    RestaurantService,
    ReservationService,
    PaymentService,
    HttpService,
    Stripe,
    UtilityService,
    TwilloProvider,
    // HttpHeaders,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}